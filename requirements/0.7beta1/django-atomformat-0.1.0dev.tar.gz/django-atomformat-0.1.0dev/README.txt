Note: this is just the atom.py from django-atompub, renamed as atomformat.py
