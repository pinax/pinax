from setuptools import setup

setup(
    name='django-atomformat',
    version='0.1.0dev',
    author='James Tauber',
    url='http://code.google.com/p/django-atompub/',
    py_modules=['atomformat'],
)
